# Algoritmos_DFS
Trabalho de algoritmos em grafos desenvolvido em python para desenvolvimento de um algoritmo de busca em profundidade.

#Paricipantes
Allan Feitosa Wariss Maia - 541564